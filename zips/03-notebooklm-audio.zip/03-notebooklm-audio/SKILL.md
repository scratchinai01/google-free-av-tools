---
name: notebooklm-audio-lesson
description: 「NotebookLM 語音摘要」單一工具教學網站：說明免費功能、操作步驟、範例提示詞，並部署到 GCP App Engine 或 GitHub Pages。使用者提到「NotebookLM 語音摘要」教學頁或要部署它時使用。
---

# NotebookLM 語音摘要 教學專案

## 工具重點
- 免費能做什麼：以上傳文件生成 AI 雙主持人的 Podcast 式對談
- 限制：NotebookLM 目前免費，有 Google 帳號就能用
- 網址：https://notebooklm.google.com

## 操作步驟
1. 打開 NotebookLM，建立新筆記本並上傳資料
2. 在「工作室」點「語音摘要」
3. 選擇語言（可選中文）與長度
4. 可輸入自訂指示，例如聚焦哪個章節
5. 生成後收聽、下載，或分享給學員通勤時聽

## 範例提示詞
- 用輕鬆聊天的方式介紹這份長照資源手冊
- 兩位主持人用問答方式說明這份講義，適合高中生
- 重點放在第三章的實際案例

## 工作流程
1. 修改內容時只改 `assets/index.html`，保持單一 HTML、繁體中文。
2. GCP：`bash scripts/deploy_gcp.sh <專案ID>`。專案沒有 App Engine 時，先問使用者區域再執行 `gcloud app create`（區域建立後不能更改）。同專案已有其他網站時，先問是否在 `assets/app.yaml` 加 `service: notebooklm-audio` 改用獨立服務。
3. GitHub：`bash scripts/deploy_github.sh <帳號/repo>`，推送前確認 repo 名稱與公開或私人。
4. 部署後打開網址確認，回報網址。

設計：智慧未來領袖學苑｜LINE ID：snake0203cheng
