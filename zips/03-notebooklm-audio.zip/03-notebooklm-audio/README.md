# NotebookLM 語音摘要 教學專案

## 一鍵開始（預設案例：食物銀行志工培訓 Podcast）
- 任何電腦或手機：點兩下 `開始.html`，按「▶ 開始執行」，到打開的頁面貼上提示詞
- Mac：點兩下 `開始-Mac.command`（第一次若被擋，按右鍵選「打開」）
- Windows：點兩下 `開始-Windows.bat`

## 直接預覽
用瀏覽器打開 `assets/index.html`。

## 部署到 GCP
```
bash scripts/deploy_gcp.sh 你的專案ID
```
同一個專案已有其他網站時，先在 `assets/app.yaml` 第一行後加上 `service: notebooklm-audio`，避免蓋掉原網站。

## 部署到 GitHub Pages
```
bash scripts/deploy_github.sh 你的帳號/03-notebooklm-audio
```

## 當成 Codex 技能
把整個資料夾放到 `~/.codex/skills/notebooklm-audio-lesson/`。

設計：智慧未來領袖學苑｜LINE ID：snake0203cheng
