---
name: youtube-shorts-lesson
description: 「YouTube Shorts」單一工具教學網站：說明免費功能、操作步驟、範例提示詞，並部署到 GCP App Engine 或 GitHub Pages。使用者提到「YouTube Shorts」教學頁或要部署它時使用。
---

# YouTube Shorts 教學專案

## 工具重點
- 免費能做什麼：Omni Flash 免費生成短影片；Dream Track 可用 Lyria 3 生成配樂
- 限制：一次生成，沒有對話式修改
- 網址：https://www.youtube.com/shorts

## 操作步驟
1. 打開 YouTube App，點「＋」選短片
2. 找到 AI 生成影片功能，輸入描述
3. 生成後挑選喜歡的版本
4. 在音效選單用 Dream Track 生成配樂
5. 加上字幕後發布或存成草稿

## 範例提示詞
- 一隻貓咪在書桌上幫忙寫作業，卡通風格
- 夕陽下的稻田，鏡頭從空中慢慢下降
- 輕快的烏克麗麗配樂，適合旅遊短片

## 工作流程
1. 修改內容時只改 `assets/index.html`，保持單一 HTML、繁體中文。
2. GCP：`bash scripts/deploy_gcp.sh <專案ID>`。專案沒有 App Engine 時，先問使用者區域再執行 `gcloud app create`（區域建立後不能更改）。同專案已有其他網站時，先問是否在 `assets/app.yaml` 加 `service: youtube-shorts` 改用獨立服務。
3. GitHub：`bash scripts/deploy_github.sh <帳號/repo>`，推送前確認 repo 名稱與公開或私人。
4. 部署後打開網址確認，回報網址。

設計：智慧未來領袖學苑｜LINE ID：snake0203cheng
