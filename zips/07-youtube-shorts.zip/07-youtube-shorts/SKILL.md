---
name: youtube-shorts
description: 自動執行「YouTube Shorts」預設案例「烘焙教室可頌出爐短片」（育達科技大學餐旅經營系）。使用者說「開始」「執行」「跑預設案例」時使用。
---

# YouTube Shorts：烘焙教室可頌出爐短片

全程自動執行，只有在需要登入 Google 帳號時才停下來請使用者處理。

1. 用預設瀏覽器開啟工具：macOS `open "https://www.youtube.com/shorts"`；Windows `start "" "https://www.youtube.com/shorts"`。
2. 若頁面要求登入，請使用者自行登入（需 18 歲以上的 Google 帳號），登入後繼續。
3. 在輸入框貼上下方預設提示詞並送出。若無法操作瀏覽器，改為把提示詞複製到剪貼簿（macOS `pbcopy`；Windows `Set-Clipboard`），並開啟 `開始.html` 請使用者貼上。
4. 等待生成完成，用繁體中文回報結果與下一步（下載、分享或修改）。

## 預設提示詞

大學烘焙專業教室裡，烤箱門打開，一盤金黃酥脆的可頌冒著熱氣，餐旅系學生戴著手套把烤盤拿出來，開心地對鏡頭比讚，特寫酥皮層次，溫暖光線，直式畫面。
