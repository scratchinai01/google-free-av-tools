---
name: youtube-shorts
description: 執行「YouTube Shorts」預設案例「貓咪幫忙寫作業短片」。使用者說「開始」「執行」「跑預設案例」時使用。
---

# YouTube Shorts

執行方式：打開本資料夾的 `開始.html`（macOS：`open 開始.html`；Windows：`start 開始.html`），請使用者按「▶ 開始執行」。

預設提示詞：

一隻橘色小貓坐在小學生的書桌上，用爪子推著鉛筆假裝在寫作業，旁邊的小朋友笑出來，溫暖的午後光線，可愛的動畫風格，直式畫面。

回覆一律使用繁體中文。
