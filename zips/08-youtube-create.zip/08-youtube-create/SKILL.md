---
name: youtube-create
description: 執行「YouTube Create App」預設案例「社區活動回顧短片」。使用者說「開始」「執行」「跑預設案例」時使用。
---

# YouTube Create App

執行方式：打開本資料夾的 `開始.html`（macOS：`open 開始.html`；Windows：`start 開始.html`），請使用者按「▶ 開始執行」。

預設提示詞：

一本相簿在木桌上緩緩打開，照片一張張浮起來，最後出現標題文字「社區活動回顧」，溫暖懷舊的色調，5 秒開場畫面。

回覆一律使用繁體中文。
