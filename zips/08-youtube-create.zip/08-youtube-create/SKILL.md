---
name: youtube-create-lesson
description: 「YouTube Create App」單一工具教學網站：說明免費功能、操作步驟、範例提示詞，並部署到 GCP App Engine 或 GitHub Pages。使用者提到「YouTube Create App」教學頁或要部署它時使用。
---

# YouTube Create App 教學專案

## 工具重點
- 免費能做什麼：Google 的免費手機影片剪輯 App，內建 Omni Flash
- 限制：僅手機版
- 網址：https://play.google.com/store/search?q=YouTube%20Create

## 操作步驟
1. 在手機安裝 YouTube Create 並登入
2. 建立新專案，匯入手機裡的照片和影片
3. 用 AI 功能生成需要的補充片段
4. 加入字幕、音樂、轉場
5. 匯出或直接上傳到 YouTube

## 範例提示詞
- 生成一段開場畫面：書本打開，標題浮現
- 生成社區活動的結尾畫面，大家揮手道別
- 補一段 5 秒的轉場：花朵慢慢綻放

## 工作流程
1. 修改內容時只改 `assets/index.html`，保持單一 HTML、繁體中文。
2. GCP：`bash scripts/deploy_gcp.sh <專案ID>`。專案沒有 App Engine 時，先問使用者區域再執行 `gcloud app create`（區域建立後不能更改）。同專案已有其他網站時，先問是否在 `assets/app.yaml` 加 `service: youtube-create` 改用獨立服務。
3. GitHub：`bash scripts/deploy_github.sh <帳號/repo>`，推送前確認 repo 名稱與公開或私人。
4. 部署後打開網址確認，回報網址。

設計：智慧未來領袖學苑｜LINE ID：snake0203cheng
