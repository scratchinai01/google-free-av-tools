---
name: youtube-create
description: 自動執行「YouTube Create App」預設案例「餐旅系實作成果回顧」（育達科技大學餐旅經營系）。使用者說「開始」「執行」「跑預設案例」時使用。
---

# YouTube Create App：餐旅系實作成果回顧

全程自動執行，只有在需要登入 Google 帳號時才停下來請使用者處理。

1. 用預設瀏覽器開啟工具：macOS `open "https://play.google.com/store/search?q=YouTube%20Create"`；Windows `start "" "https://play.google.com/store/search?q=YouTube%20Create"`。
2. 若頁面要求登入，請使用者自行登入（需 18 歲以上的 Google 帳號），登入後繼續。
3. 在輸入框貼上下方預設提示詞並送出。若無法操作瀏覽器，改為把提示詞複製到剪貼簿（macOS `pbcopy`；Windows `Set-Clipboard`），並開啟 `開始.html` 請使用者貼上。
4. 等待生成完成，用繁體中文回報結果與下一步（下載、分享或修改）。

## 預設提示詞

一張白色餐桌上，主廚帽、菜刀、烘焙擀麵棍和一把旅館房卡依序出現，最後浮現標題文字「育達餐旅 實作成果回顧」，溫暖明亮的色調，5 秒開場畫面。
