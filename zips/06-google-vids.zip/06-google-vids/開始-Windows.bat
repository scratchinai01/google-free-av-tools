@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell -NoProfile -Command "Get-Content -Raw -Encoding UTF8 'preset\prompt.txt' | Set-Clipboard"
start "" "https://docs.google.com/videos/"
start "" "%~dp0開始.html"
