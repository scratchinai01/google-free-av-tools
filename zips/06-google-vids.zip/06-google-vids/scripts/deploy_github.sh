#!/usr/bin/env bash
set -euo pipefail
REPO="${1:?用法：bash scripts/deploy_github.sh <帳號/repo>}"
DIR="$(cd "$(dirname "$0")/../assets" && pwd)"
cd "$DIR"
[ -d .git ] || git init -b main
git add -A
git commit -m "部署教學網站" || true
if ! gh repo view "$REPO" >/dev/null 2>&1; then
  gh repo create "$REPO" --public --source=. --remote=origin
fi
git remote get-url origin >/dev/null 2>&1 || git remote add origin "https://github.com/$REPO.git"
git push -u origin main
gh api -X POST "repos/$REPO/pages" -f build_type=workflow >/dev/null 2>&1 || true
echo "完成。約 1～2 分鐘後開啟：https://${REPO%%/*}.github.io/${REPO#*/}/"
