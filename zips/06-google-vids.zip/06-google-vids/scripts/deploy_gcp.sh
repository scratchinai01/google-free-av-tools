#!/usr/bin/env bash
set -euo pipefail
PROJECT="${1:?用法：bash scripts/deploy_gcp.sh <專案ID>}"
DIR="$(cd "$(dirname "$0")/../assets" && pwd)"
gcloud config set project "$PROJECT"
if ! gcloud app describe >/dev/null 2>&1; then
  echo "此專案尚未建立 App Engine。區域建立後無法更改，請確認後手動執行："
  echo "  gcloud app create --region=asia-east1"
  exit 1
fi
cd "$DIR"
gcloud app deploy --quiet
gcloud app browse --no-launch-browser
