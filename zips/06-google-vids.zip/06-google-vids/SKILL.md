---
name: google-vids-lesson
description: 「Google Vids」單一工具教學網站：說明免費功能、操作步驟、範例提示詞，並部署到 GCP App Engine 或 GitHub Pages。使用者提到「Google Vids」教學頁或要部署它時使用。
---

# Google Vids 教學專案

## 工具重點
- 免費能做什麼：所有 Google 帳號都能免費用 Veo 3.1 生成影片片段
- 限制：Vids 裡的 Lyria 配樂生成僅限 Pro/Ultra 付費用戶
- 網址：https://docs.google.com/videos/

## 操作步驟
1. 打開 Google Vids，建立新影片
2. 用範本或空白專案開始
3. 在插入選單選 AI 生成影片片段，輸入描述
4. 加入文字、旁白與素材，排好時間軸
5. 完成後分享或下載

## 範例提示詞
- 生成一段 8 秒的教室畫面，學生舉手發問
- 生成社區志工整理物資的畫面，溫馨紀錄片風格
- 做一支 1 分鐘的課程介紹影片

## 工作流程
1. 修改內容時只改 `assets/index.html`，保持單一 HTML、繁體中文。
2. GCP：`bash scripts/deploy_gcp.sh <專案ID>`。專案沒有 App Engine 時，先問使用者區域再執行 `gcloud app create`（區域建立後不能更改）。同專案已有其他網站時，先問是否在 `assets/app.yaml` 加 `service: google-vids` 改用獨立服務。
3. GitHub：`bash scripts/deploy_github.sh <帳號/repo>`，推送前確認 repo 名稱與公開或私人。
4. 部署後打開網址確認，回報網址。

設計：智慧未來領袖學苑｜LINE ID：snake0203cheng
