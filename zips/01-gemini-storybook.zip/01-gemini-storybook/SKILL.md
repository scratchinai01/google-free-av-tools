---
name: gemini-storybook-lesson
description: 「Gemini Storybook（故事書）」單一工具教學網站：說明免費功能、操作步驟、範例提示詞，並部署到 GCP App Engine 或 GitHub Pages。使用者提到「Gemini Storybook（故事書）」教學頁或要部署它時使用。
---

# Gemini Storybook（故事書） 教學專案

## 工具重點
- 免費能做什麼：輸入故事描述就生成 10 頁插畫故事書，附朗讀旁白
- 限制：免費開放給所有 18 歲以上使用者
- 網址：https://gemini.google.com/gem/storybook

## 操作步驟
1. 打開 Gemini 故事書頁面，登入 Google 帳號
2. 描述故事主角、場景、想傳達的道理與讀者年齡
3. 可上傳照片或孩子的畫作當作角色靈感
4. 等待生成 10 頁故事書，按播放聽朗讀
5. 不滿意就在對話中要求修改劇情或畫風，完成後分享連結或列印

## 範例提示詞
- 幫我做一本給 5 歲孩子的故事書：小兔子學會排隊，水彩畫風
- 用這張阿嬤的照片當主角，寫一本關於阿嬤年輕時種稻的故事
- 做一本認識詐騙電話的故事書，給長輩看，字少圖多

## 工作流程
1. 修改內容時只改 `assets/index.html`，保持單一 HTML、繁體中文。
2. GCP：`bash scripts/deploy_gcp.sh <專案ID>`。專案沒有 App Engine 時，先問使用者區域再執行 `gcloud app create`（區域建立後不能更改）。同專案已有其他網站時，先問是否在 `assets/app.yaml` 加 `service: gemini-storybook` 改用獨立服務。
3. GitHub：`bash scripts/deploy_github.sh <帳號/repo>`，推送前確認 repo 名稱與公開或私人。
4. 部署後打開網址確認，回報網址。

設計：智慧未來領袖學苑｜LINE ID：snake0203cheng
