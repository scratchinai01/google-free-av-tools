---
name: gemini-omni-flow-lesson
description: 「Gemini Omni（透過 Flow）」單一工具教學網站：說明免費功能、操作步驟、範例提示詞，並部署到 GCP App Engine 或 GitHub Pages。使用者提到「Gemini Omni（透過 Flow）」教學頁或要部署它時使用。
---

# Gemini Omni（透過 Flow） 教學專案

## 工具重點
- 免費能做什麼：所有使用者都能用 Omni 模型，包括 10 秒短片和影片編輯
- 限制：Gemini App 裡用 Omni 生成影片要付費，免費版請改走 Flow 或 YouTube
- 網址：https://labs.google/fx/tools/flow

## 操作步驟
1. 打開 Google Flow，模型選 Omni
2. 輸入描述生成 10 秒短片
3. 用一般說話的方式要求修改，例如換背景、改天氣
4. 可加入參考圖讓角色保持一致
5. 滿意後下載或加入 Flow 專案

## 範例提示詞
- 把背景換成下雨的夜晚，其他不變
- 讓主角改成揮手微笑
- 同一個角色，換到海邊再做一段

## 工作流程
1. 修改內容時只改 `assets/index.html`，保持單一 HTML、繁體中文。
2. GCP：`bash scripts/deploy_gcp.sh <專案ID>`。專案沒有 App Engine 時，先問使用者區域再執行 `gcloud app create`（區域建立後不能更改）。同專案已有其他網站時，先問是否在 `assets/app.yaml` 加 `service: gemini-omni-flow` 改用獨立服務。
3. GitHub：`bash scripts/deploy_github.sh <帳號/repo>`，推送前確認 repo 名稱與公開或私人。
4. 部署後打開網址確認，回報網址。

設計：智慧未來領袖學苑｜LINE ID：snake0203cheng
