---
name: gemini-music-lesson
description: 「Gemini 音樂（Lyria 3）」單一工具教學網站：說明免費功能、操作步驟、範例提示詞，並部署到 GCP App Engine 或 GitHub Pages。使用者提到「Gemini 音樂（Lyria 3）」教學頁或要部署它時使用。
---

# Gemini 音樂（Lyria 3） 教學專案

## 工具重點
- 免費能做什麼：在 Gemini 的「工具」選單點「音樂」，用文字、圖片、音訊或影片生成 30 秒歌曲
- 限制：限 18 歲以上，免費版次數較少
- 網址：https://gemini.google.com/music

## 操作步驟
1. 打開 Gemini，點「工具」選「音樂」
2. 描述曲風、情緒、樂器、要不要人聲
3. 也可以上傳照片或影片當靈感
4. 生成 30 秒歌曲後試聽
5. 不滿意就調整描述重新生成，滿意後下載

## 範例提示詞
- 輕快的台語歌，主題是阿公阿嬤去市場買菜
- 溫柔的鋼琴純音樂，適合放在長照課程影片背景
- 用這張畢業照寫一首感謝老師的歌，國語女聲

## 工作流程
1. 修改內容時只改 `assets/index.html`，保持單一 HTML、繁體中文。
2. GCP：`bash scripts/deploy_gcp.sh <專案ID>`。專案沒有 App Engine 時，先問使用者區域再執行 `gcloud app create`（區域建立後不能更改）。同專案已有其他網站時，先問是否在 `assets/app.yaml` 加 `service: gemini-music` 改用獨立服務。
3. GitHub：`bash scripts/deploy_github.sh <帳號/repo>`，推送前確認 repo 名稱與公開或私人。
4. 部署後打開網址確認，回報網址。

設計：智慧未來領袖學苑｜LINE ID：snake0203cheng
