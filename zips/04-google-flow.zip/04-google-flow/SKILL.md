---
name: google-flow-lesson
description: 「Google Flow」單一工具教學網站：說明免費功能、操作步驟、範例提示詞，並部署到 GCP App Engine 或 GitHub Pages。使用者提到「Google Flow」教學頁或要部署它時使用。
---

# Google Flow 教學專案

## 工具重點
- 免費能做什麼：每天 50 點免費 Flow 點數，含 Gemini Omni Flash、Nano Banana Pro、Veo 3.1、Agent、文字轉影片、畫格轉影片
- 限制：免費版不能做 1080p 升級，尖峰時段影片可能被擋
- 網址：https://labs.google/fx/tools/flow

## 操作步驟
1. 打開 Google Flow，登入 Google 帳號
2. 建立新專案，選擇文字轉影片或畫格轉影片
3. 輸入畫面描述：主角、動作、鏡頭、光線
4. 生成後用 Agent 或編輯功能調整
5. 把多段片段排進場景，匯出影片

## 範例提示詞
- 清晨的台中公園，長輩在打太極，鏡頭緩慢推近，溫暖陽光
- 一隻紙雕小鳥從書本中飛出來，翻頁特寫，柔和光線
- 上傳兩張圖當首尾畫格，生成兩者之間的轉場

## 工作流程
1. 修改內容時只改 `assets/index.html`，保持單一 HTML、繁體中文。
2. GCP：`bash scripts/deploy_gcp.sh <專案ID>`。專案沒有 App Engine 時，先問使用者區域再執行 `gcloud app create`（區域建立後不能更改）。同專案已有其他網站時，先問是否在 `assets/app.yaml` 加 `service: google-flow` 改用獨立服務。
3. GitHub：`bash scripts/deploy_github.sh <帳號/repo>`，推送前確認 repo 名稱與公開或私人。
4. 部署後打開網址確認，回報網址。

設計：智慧未來領袖學苑｜LINE ID：snake0203cheng
