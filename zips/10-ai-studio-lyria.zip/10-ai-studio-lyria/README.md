# Google AI Studio（Lyria） 教學專案

## 直接預覽
用瀏覽器打開 `assets/index.html`。

## 部署到 GCP
```
bash scripts/deploy_gcp.sh 你的專案ID
```
同一個專案已有其他網站時，先在 `assets/app.yaml` 第一行後加上 `service: ai-studio-lyria`，避免蓋掉原網站。

## 部署到 GitHub Pages
```
bash scripts/deploy_github.sh 你的帳號/10-ai-studio-lyria
```

## 當成 Codex 技能
把整個資料夾放到 `~/.codex/skills/ai-studio-lyria-lesson/`。

設計：智慧未來領袖學苑｜LINE ID：snake0203cheng
