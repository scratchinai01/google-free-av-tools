---
name: ai-studio-lyria
description: 自動執行「Google AI Studio（Lyria）」預設案例「實習餐廳背景爵士樂」（育達科技大學餐旅經營系）。使用者說「開始」「執行」「跑預設案例」時使用。
---

# Google AI Studio（Lyria）：實習餐廳背景爵士樂

全程自動執行，只有在需要登入 Google 帳號時才停下來請使用者處理。

1. 用預設瀏覽器開啟工具：macOS `open "https://aistudio.google.com"`；Windows `start "" "https://aistudio.google.com"`。
2. 若頁面要求登入，請使用者自行登入（需 18 歲以上的 Google 帳號），登入後繼續。
3. 在輸入框貼上下方預設提示詞並送出。若無法操作瀏覽器，改為把提示詞複製到剪貼簿（macOS `pbcopy`；Windows `Set-Clipboard`），並開啟 `開始.html` 請使用者貼上。
4. 等待生成完成，用繁體中文回報結果與下一步（下載、分享或修改）。

## 預設提示詞

Relaxed smooth jazz for a university training restaurant during lunch service, 30 seconds, soft piano, upright bass and brushed drums, warm and elegant mood, no vocals.
