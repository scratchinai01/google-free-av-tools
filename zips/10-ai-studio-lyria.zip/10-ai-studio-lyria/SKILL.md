---
name: ai-studio-lyria-lesson
description: 「Google AI Studio（Lyria）」單一工具教學網站：說明免費功能、操作步驟、範例提示詞，並部署到 GCP App Engine 或 GitHub Pages。使用者提到「Google AI Studio（Lyria）」教學頁或要部署它時使用。
---

# Google AI Studio（Lyria） 教學專案

## 工具重點
- 免費能做什麼：可免費試用 Lyria 音樂生成
- 限制：介面偏開發者，較不適合一般學員
- 網址：https://aistudio.google.com

## 操作步驟
1. 打開 Google AI Studio 並登入
2. 在模型或媒體生成區找到 Lyria
3. 輸入音樂描述，調整長度等設定
4. 生成後試聽與下載
5. 進階者可取得程式碼範例串接到自己的網站

## 範例提示詞
- Lo-fi 嘻哈節奏，適合讀書時聽
- 史詩感管弦樂，用於課程片頭
- 可即時調整節奏的電子音樂

## 工作流程
1. 修改內容時只改 `assets/index.html`，保持單一 HTML、繁體中文。
2. GCP：`bash scripts/deploy_gcp.sh <專案ID>`。專案沒有 App Engine 時，先問使用者區域再執行 `gcloud app create`（區域建立後不能更改）。同專案已有其他網站時，先問是否在 `assets/app.yaml` 加 `service: ai-studio-lyria` 改用獨立服務。
3. GitHub：`bash scripts/deploy_github.sh <帳號/repo>`，推送前確認 repo 名稱與公開或私人。
4. 部署後打開網址確認，回報網址。

設計：智慧未來領袖學苑｜LINE ID：snake0203cheng
