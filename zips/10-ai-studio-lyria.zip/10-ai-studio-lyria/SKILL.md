---
name: ai-studio-lyria
description: 執行「Google AI Studio（Lyria）」預設案例「課程片頭配樂」。使用者說「開始」「執行」「跑預設案例」時使用。
---

# Google AI Studio（Lyria）

執行方式：打開本資料夾的 `開始.html`（macOS：`open 開始.html`；Windows：`start 開始.html`），請使用者按「▶ 開始執行」。

預設提示詞：

A bright and hopeful orchestral opening theme for an education video, 20 seconds, soft piano intro building to strings and light percussion, warm and inspiring mood, no vocals.

回覆一律使用繁體中文。
