#!/bin/bash
cd "$(dirname "$0")"
pbcopy < preset/prompt.txt
open "https://aistudio.google.com"
open "開始.html"
echo "預設提示詞已複製，請在打開的頁面按 ⌘+V 貼上。"
