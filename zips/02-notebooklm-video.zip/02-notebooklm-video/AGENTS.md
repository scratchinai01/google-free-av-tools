# AGENTS.md

本專案是「NotebookLM 影片摘要」單一工具教學網站。

- 回覆與介面一律使用繁體中文。
- 網站只有 `assets/index.html`，不要引入框架或建置工具。
- 建立 App Engine 區域、推送公開 repo 前必須先問使用者。
