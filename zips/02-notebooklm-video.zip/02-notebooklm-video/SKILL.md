---
name: notebooklm-video-lesson
description: 「NotebookLM 影片摘要」單一工具教學網站：說明免費功能、操作步驟、範例提示詞，並部署到 GCP App Engine 或 GitHub Pages。使用者提到「NotebookLM 影片摘要」教學頁或要部署它時使用。
---

# NotebookLM 影片摘要 教學專案

## 工具重點
- 免費能做什麼：把筆記、PDF、圖片轉成視覺化簡報影片，會引用文件裡的圖表、引言和數據
- 限制：限 18 歲以上
- 網址：https://notebooklm.google.com

## 操作步驟
1. 打開 NotebookLM，建立新筆記本
2. 上傳 PDF、Google 文件、網址或圖片當來源
3. 在右側「工作室」點「影片摘要」
4. 可自訂重點、目標觀眾與學習目標
5. 生成完成後播放、下載或分享

## 範例提示詞
- 請做給社區長輩看的影片摘要，重點放在防跌倒的三個方法
- 以國小老師為觀眾，整理這份課綱的重點與教學建議
- 用 5 分鐘說明這份報告的數據重點

## 工作流程
1. 修改內容時只改 `assets/index.html`，保持單一 HTML、繁體中文。
2. GCP：`bash scripts/deploy_gcp.sh <專案ID>`。專案沒有 App Engine 時，先問使用者區域再執行 `gcloud app create`（區域建立後不能更改）。同專案已有其他網站時，先問是否在 `assets/app.yaml` 加 `service: notebooklm-video` 改用獨立服務。
3. GitHub：`bash scripts/deploy_github.sh <帳號/repo>`，推送前確認 repo 名稱與公開或私人。
4. 部署後打開網址確認，回報網址。

設計：智慧未來領袖學苑｜LINE ID：snake0203cheng
